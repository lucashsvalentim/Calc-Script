        DataGrid grid = null;
	    String planElementDimName = "Plan Element"
        String flexDim1Name = "Contrato"
		String flexDim2Name = "Empresa"
		String flexDim3Name = "Visao"
		String productDimName  = "Empreendimento"
		String serviceDimName  = "RevenueSource2"
		String entityDimName = "Entity"
        Cube financialsCube = operation.cube
		def weeklyCondition
		boolean is13PeriodApp = TemporaryInternalMethods.is13PeriodApp()
		weeklyCondition = is13PeriodApp ? '(@ismbr(@remove(@relative("OEP_Weekly Plan", 0),"OEP_W53"))) or ("TP-Weeks" == 53 and @ismbr(@relative("OEP_Weekly Plan", 0)))' : '@ismbr(@relative("OEP_Weekly Plan", 0))'
		try {
        	grid = operation.grid;
        } catch(BindingsMissingException) {
        	return  '''OFS_Calculated (
          			@RETURN(@HspMessage("ID_Err_FINANCIALS_TREND_BASED_TO_BE_RUN_FROM_FORM"),ERROR);
                   )'''
        }
        //Check if the trend is revision trend or not
        Map<Long, Set<String>> trendsAndAccountsMap = [:]
        grid.dataCellIterator({ DataCell cell -> !cell.missing && cell.getMemberName(planElementDimName) == "OFS_Trend" && cell.periodName == "BegBalance"}).each { dataCell ->
        	long trend = (long) dataCell.data
        	Set<String> accounts = trendsAndAccountsMap.get(trend)
            if(!accounts) {
            	accounts = new HashSet<String>()
            	trendsAndAccountsMap.put(trend, accounts)
            }
			accounts.add(dataCell.accountName)
		}
        %Template(name:="OFS_GridMemberSelection_GT",plantype:="OEP_FS",dtps:=())
		GridMemberSelection gridMemberSelection = new GridMemberSelection(grid)
        Set<Long> capturedTrends = trendsAndAccountsMap.keySet()
		long CURRENT_PERIOD_ACTUAL_TREND = 2l
		long CLEAR_TREND = 12l
		long CURRENT_YEAR_ENCUMBRANCE_TREND = 51l
		long NET_CURRENT_BUDGET_TREND = 56l
		long CURRENT_YEAR_APPROVED_BUDGET_TREND = 61l
		long CURRENT_YEAR_ORIGINAL_BUDGET_TREND = 66l
        Set<Long> exclusiveRevisionTrends = [CURRENT_YEAR_ENCUMBRANCE_TREND, CURRENT_YEAR_APPROVED_BUDGET_TREND, CURRENT_YEAR_ORIGINAL_BUDGET_TREND, NET_CURRENT_BUDGET_TREND] as HashSet
		Set<Long> revisionTrendsWithOutClearTrend = exclusiveRevisionTrends + [CURRENT_PERIOD_ACTUAL_TREND]
        Set<Long> revisionTrends = revisionTrendsWithOutClearTrend + [CLEAR_TREND]
        def versionDimension = operation.application.getDimension(DimensionType.VERSION, financialsCube)
        def netCurrentBudgetRevisions = versionDimension.hasMember("OEP_Net Current Budget", financialsCube) ? (versionDimension.getEvaluatedMembers(/ILvl0Descendants("OEP_Net Current Budget")/, financialsCube).collect{it.toString()}) : []
        def budgetRevisionVersions = netCurrentBudgetRevisions - "[OEP_Net Current Budget].[OEP_Working]"
        String version = gridMemberSelection.getMemberFromSelection("Version")
        boolean isBudgetRevision = version in budgetRevisionVersions
		//FIXME: What to do when no accounts,trend, Adjustment percentage are modified. Need to identify the Version is a Revision version or not
        if(isBudgetRevision) {
        	if(!revisionTrends.containsAll(capturedTrends)) {
            	throwVetoException("You can't use the trend you selected in a budget revision. Valid trends are ${revisionTrends.collect{operation.application.getSmartList("OFS_Trend").getEntry(it).getLabel()}}.")
            }
            def periodSelectionForDataCopy = 'ILvl0Descendants("YearTotal"),ILvl0Descendants("OEP_Qrtly Plan"),ILvl0Descendants("OEP_Yearly Plan")'
            def yearsSelection = gridMemberSelection.getMemberSelection("Years")
            def entitySelection = gridMemberSelection.getMemberSelection(entityDimName)
            def currencySelection
            if(operation.application.getCurrencyMode().equals(CurrencyMode.SIMPLIFIED_MULTI_CURRENCY)){
            	currencySelection = gridMemberSelection.getMemberSelection("Currency")
            }
            def flexDim1Selection
            if(operation.application.hasDimension(flexDim1Name, financialsCube)){
            	flexDim1Selection = gridMemberSelection.getMemberSelection(flexDim1Name)
            }
            def flexDim2Selection
            if(operation.application.hasDimension(flexDim2Name, financialsCube)){
            	flexDim2Selection = gridMemberSelection.getMemberSelection(flexDim2Name)
            }
            def flexDim3Selection
            if(operation.application.hasDimension(flexDim3Name, financialsCube)){
            	flexDim3Selection = gridMemberSelection.getMemberSelection(flexDim3Name)
            }
            def productDimSelection
            if(operation.application.hasDimension(productDimName, financialsCube)){
            	productDimSelection = gridMemberSelection.getMemberSelection(productDimName)
            }
            def serviceDimSelection
            if(operation.application.hasDimension(serviceDimName, financialsCube)){
            	serviceDimSelection = gridMemberSelection.getMemberSelection(serviceDimName)
            }
			List<String> fixMembers = []
			fixMembers.addAll(yearsSelection)
            fixMembers.addAll(entitySelection)
			if(currencySelection) {
				fixMembers.addAll(currencySelection)
			}
			if(flexDim1Selection) {
				fixMembers.addAll(flexDim1Selection)
			}
			if(flexDim2Selection) {
				fixMembers.addAll(flexDim2Selection)
			}
			if(flexDim3Selection) {
				fixMembers.addAll(flexDim3Selection)
			}
			if(productDimSelection) {
				fixMembers.addAll(productDimSelection)
			}
			if(serviceDimSelection) {
				fixMembers.addAll(serviceDimSelection)
			}
        	capturedTrends.each { trendSmartListEntryId ->
                def dimToDimMapping = ["Period":(trendSmartListEntryId == CURRENT_PERIOD_ACTUAL_TREND? "&OEP_CurMnth" : periodSelectionForDataCopy), "Years":yearsSelection.collect{/"$it"/}.join(','), (entityDimName):entitySelection.collect{/"$it"/}.join(',')]
                if(currencySelection) {
                	dimToDimMapping.put("Currency", currencySelection.collect{/"$it"/}.join(','))
                }
                if(flexDim1Selection) {
                	dimToDimMapping.put(flexDim1Name, flexDim1Selection.collect{/"$it"/}.join(','))
                }
                if(flexDim2Selection) {
                	dimToDimMapping.put(flexDim2Name, flexDim2Selection.collect{/"$it"/}.join(','))
                }
                if(flexDim3Selection) {
                	dimToDimMapping.put(flexDim3Name, flexDim3Selection.collect{/"$it"/}.join(','))
                }
                if(productDimSelection) {
                	dimToDimMapping.put(productDimName, productDimSelection.collect{/"$it"/}.join(','))
                }
                if(serviceDimSelection) {
                	dimToDimMapping.put(serviceDimName, serviceDimSelection.collect{/"$it"/}.join(','))
                }
            	def accountMembers = trendsAndAccountsMap.get(trendSmartListEntryId)
                dimToDimMapping.put("Account", accountMembers.collect{/"$it"/}.join(','))
                String sourceScenarioSelectionForDataCopy, targetScenarioSelectionForDataCopy, sourceVersionSelectionForDataCopy, sourcePlanElementSelectionForDataCopy, targetPlanElementSelectionForDataCopy
                if(trendSmartListEntryId == CURRENT_YEAR_ENCUMBRANCE_TREND) {
                    sourceScenarioSelectionForDataCopy = 'OEP_Consumed'
                    targetScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    sourceVersionSelectionForDataCopy = 'OEP_Working'
                    sourcePlanElementSelectionForDataCopy = 'ILvl0Descendants("OFS_Total Plan")'
                    targetPlanElementSelectionForDataCopy = 'OFS_Calculated'
                } else if(trendSmartListEntryId == CURRENT_PERIOD_ACTUAL_TREND) {
                    sourceScenarioSelectionForDataCopy = 'OEP_Actual'
                    targetScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    sourceVersionSelectionForDataCopy = 'OEP_Working'
                    sourcePlanElementSelectionForDataCopy = 'ILvl0Descendants("OFS_Total Plan")'
                    targetPlanElementSelectionForDataCopy = 'OFS_Calculated'
                } else if(trendSmartListEntryId == CURRENT_YEAR_APPROVED_BUDGET_TREND) {
                    sourceScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    targetScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    sourceVersionSelectionForDataCopy = 'OEP_Working'
                    sourcePlanElementSelectionForDataCopy = 'ILvl0Descendants("OFS_Total Plan")'
                    targetPlanElementSelectionForDataCopy = 'OFS_Calculated'
                } else if(trendSmartListEntryId == CURRENT_YEAR_ORIGINAL_BUDGET_TREND) {
                    sourceScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    targetScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    sourceVersionSelectionForDataCopy = 'OEP_Original'
                    sourcePlanElementSelectionForDataCopy = 'ILvl0Descendants("OFS_Total Plan")'
                    targetPlanElementSelectionForDataCopy = 'OFS_Calculated'
                } else if(trendSmartListEntryId == NET_CURRENT_BUDGET_TREND) {
                    sourceScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    targetScenarioSelectionForDataCopy = 'OEP_Adopted Budget'
                    //sourceVersionSelectionForDataCopy = 'ILvl0Descendants("OEP_Net Current Budget")'
                    sourceVersionSelectionForDataCopy = (netCurrentBudgetRevisions - version).collect{/"$it"/}.join(',')
                    sourcePlanElementSelectionForDataCopy = 'ILvl0Descendants("OFS_Total Plan")'
                    targetPlanElementSelectionForDataCopy = 'OFS_Calculated'
                } else if(trendSmartListEntryId == CLEAR_TREND) {
                    //Valid trend
                } else {
                    //FIXME: Remove this after handling all trends
                    throwVetoException("You can't select the trend: " + operation.application.getSmartList("OFS_Trend").getEntry(trendSmartListEntryId).getLabel())
                }
				
				if(trendSmartListEntryId != CLEAR_TREND) {
					Map<String,String> unmappedSource = ["Scenario":sourceScenarioSelectionForDataCopy, "Version":sourceVersionSelectionForDataCopy, (planElementDimName):sourcePlanElementSelectionForDataCopy]
					Map<String,String> unmappedTarget = ["Scenario":targetScenarioSelectionForDataCopy, "Version":version, (planElementDimName):targetPlanElementSelectionForDataCopy]
					TemporaryInternalMethods.copyAndAggregateDataOfBudgetRevision("OnTheFlyDataMap", financialsCube, dimToDimMapping, unmappedSource, unmappedTarget, true)
				}
            }
			if(capturedTrends) {
				def revisionCalc = ''
				if(trendsAndAccountsMap.containsKey(CLEAR_TREND)) {
					revisionCalc += """
						FIX(${fixMembers.collect{/"$it"/}.join(',')},${trendsAndAccountsMap.get(CLEAR_TREND).collect{/"$it"/}.join(',')},"OEP_Adopted Budget")
                        	FIX("OFS_Calculated", @Relative("YearTotal",0), @relative("OEP_Qrtly Plan",0), @relative("OEP_Yearly Plan",0))
								$version = #missing;
                            ENDFIX;
                            FIX("OFS_% Increase/(Decrease)", "BegBalance")
                            	$version = #missing;
                            ENDFIX;
						ENDFIX;"""
				}
				
				if(trendsAndAccountsMap.keySet().intersect(revisionTrendsWithOutClearTrend as HashSet)) {
                    revisionCalc += """
                    				FIX(${fixMembers.collect{/"$it"/}.join(',')},"OEP_Adopted Budget", "OFS_Calculated")"""
					if(trendsAndAccountsMap.keySet() - [CURRENT_PERIOD_ACTUAL_TREND, CLEAR_TREND]) {
						revisionCalc += """
							FIX(@Relative("YearTotal",0), @relative("OEP_Qrtly Plan",0), @relative("OEP_Yearly Plan",0), ${trendsAndAccountsMap.entrySet().collect{it.key!=CLEAR_TREND && it.key!=CURRENT_PERIOD_ACTUAL_TREND?it.value:[]}.flatten().collect{/"$it"/}.join(',')})
								$version = $version * "OFS_% Increase/(Decrease)"->"BegBalance";
							ENDFIX;"""
					}
					
					if(trendsAndAccountsMap.containsKey(CURRENT_PERIOD_ACTUAL_TREND)) {
						revisionCalc += """
						FIX(@Relative("YearTotal",0), ${trendsAndAccountsMap.get(CURRENT_PERIOD_ACTUAL_TREND).collect{/"$it"/}.join(',')})
							$version = $version -> &OEP_CurMnth * "OFS_% Increase/(Decrease)"->"BegBalance";
						ENDFIX;"""
					}
                    revisionCalc += """
                    				ENDFIX;"""
				}
				
				revisionCalc += """
						FIX(${fixMembers.collect{/"$it"/}.join(',')},$version,"OEP_Adopted Budget", "OFS_Calculated", @Relative("YearTotal",0), @relative("OEP_Qrtly Plan",0), @relative("OEP_Yearly Plan",0))
							CALC DIM("Account");
						ENDFIX;"""
				financialsCube.executeCalcScript(revisionCalc)
			}
        	
        } else {
			if(capturedTrends.intersect(exclusiveRevisionTrends)) {
            	throwVetoException("You can't use the trend you selected. You can use ${exclusiveRevisionTrends.collect{operation.application.getSmartList("OFS_Trend").getEntry(it).getLabel()}} trends only in budget revision versions.")
			}
        	boolean processAccount = false;
			StringBuilder cscript = new StringBuilder(); // The variable that contains the actual script that will be returned at the end.
			List<DataGrid.HeaderCell> povs = grid.getPov();
			List<String> fixMembers = new ArrayList<String>();
			Set<String> accts = new HashSet<String>();
			List<String> periods = new ArrayList<String>();
			for (DataGrid.HeaderCell cell : povs) {
				if (cell.isCalcableForPOV()) {
					if ((!(cell.isZoomable())) && !cell.getDimName().equals(planElementDimName) ) {
						fixMembers.add(cell.getEssbaseMbrName());
					} else if (cell.getDimName().equalsIgnoreCase("Account")) {
						 String memName = cell.getEssbaseMbrName();
						 if(memName == null)
							  memName = cell.getMbrName();
						 accts.add(memName);
						processAccount = true;
					}else if (cell.getDimName().equalsIgnoreCase("Period") ) {
							if(cell.isCalcableForPOV()){
							   String memName = cell.getEssbaseMbrName();
							   if(memName == null)
									memName = cell.getMbrName();
							   if(!periods.contains(memName))
								periods.add(memName);
						   }
					}
				}
			}

			List<DataGrid.Row> rows = grid.getRows();

			//Since need to fix on Periods, removing the processAccount check. If Accounts are already processed, it will not come here anyways.
				for (DataGrid.Row row : rows) {
					List<DataGrid.HeaderCell> subRows = row.getHeaders();
					for (DataGrid.HeaderCell cell : subRows) {
						if (cell.getDimName().equalsIgnoreCase("Account")) {
						  String memName = cell.getEssbaseMbrName();
						  if(memName == null)
							  memName = cell.getMbrName();
						   accts.add(memName);
							processAccount = true;
						}else if (cell.getDimName().equalsIgnoreCase("Period") ) {
							if(cell.isCalcableForPOV()){
							   String memName = cell.getEssbaseMbrName();
							   if(memName == null)
									memName = cell.getMbrName();
							   if(!periods.contains(memName))
								periods.add(memName);
						   }
						} 
					}
				}


			
				List<List<DataGrid.HeaderCell>> cols = grid.getColumns();
				for (List<DataGrid.HeaderCell> cells : cols) {
					for (DataGrid.HeaderCell cell : cells) {
						if (cell.getDimName().equalsIgnoreCase("Account")) {
						  String memName = cell.getEssbaseMbrName();
						  if(memName == null)
							  memName = cell.getMbrName();
						   accts.add(memName);
							processAccount = true;
						}else if (cell.getDimName().equalsIgnoreCase("Period") ) {
							if(cell.isCalcableForPOV()){
							   String memName = cell.getEssbaseMbrName();
							   if(memName == null)
									memName = cell.getMbrName();
							   if(!periods.contains(memName))
								periods.add(memName);
						   }
						} else {
							break;
						}
					}
				}
			

			int indx = 0;
			for (String fixMbr : fixMembers) {
				if (indx == 0) {

					cscript.append('''FIX( ''');
				}

				 cscript.append("\"" + fixMbr + "\"");
				if (indx < (fixMembers.size() - 1))
					 cscript.append(",");
				indx++;
			}

			for (String fixMbr : periods) {
			   if(indx > 0 ){
				  cscript.append(",");
				  cscript.append("\"" + fixMbr + "\"");
				}
			}
			

			if (fixMembers.size() > 0)
				 cscript.append(")\n");

			if (accts.size() > 0)
				processAccount = true;

			indx = 0;

			for (String acct : accts) {
				if (indx == 0) {
					String msg = "";
					
					 cscript.append('''FIX(''');

				}

				 cscript.append("\"" + acct + "\"");
				if (indx < (accts.size() - 1))
					cscript.append(",");
				indx++;
			}

			if (processAccount) {
				 cscript.append(") \n");
				 
				  cscript.append("\"OFS_Calculated\" ( \n")
				if(operation.application.currencyMode == CurrencyMode.SIMPLIFIED_MULTI_CURRENCY) {
					 cscript.append("if(@ismbr(@relative(\"Input Currencies\",0))) \n ")
				}

				 def trendLogic = '''
			 if(@ismbr("OEP_Forecast"))	

			 '''  ;
			 
			 def weeklyScript = """
		if($weeklyCondition)    
			If(@sumrange(&OEP_CurYr->OEP_Actual->OFS_Load,OEP_W1:&OEP_CurWeek)<>#missing) 					   	
				If(Not(@ismbr(&OEP_CurYr) and @ismbr(OEP_W1:&OEP_CurWeek))) 
					%Script(name:="Weekly_Trends")									
					%Script(name:="Weekly_ForecastOnly")											
					endif         
				endif 
			endif
		else
			if(@ismbr(@relative("YearTotal",0)))			
				If(Not(@ismbr(&OEP_CurYr) and @ismbr(&OEP_StartMnth:&OEP_CurMnth)))		
					%Script(name:="Monthly_Trends")	
					%Script(name:="Forecast_Only_Trends")	
					endif 	
				endif		
			
			elseif(@ismbr(@relative("OEP_Qrtly Plan",0)))
				if(@ismbr(&OEP_QrtlyFcstStart:&OEP_QrtlyFcstEnd))	
						%Script(name:="Qrtly_Trends")											
				endif
			
			elseif(@ismbr("OEP_Yearly Plan"))
				if(@ismbr(&OEP_YrlyFcstStart:&OEP_YrlyFcstEnd))																											
					%Script(name:="Yearly_Trends")											
				endif													
			endif
		 endif   
	elseif(@ismbr("OEP_Plan"))	
			if(@ismbr(@relative("OEP_Weekly Plan",0)))
				  %Script(name:="Weekly_Trends")	
				   %Script(name:="Plan_Only_Weekly")	
				  endif
			
			elseif(@ismbr(@relative("YearTotal",0)))																											
					%Script(name:="Monthly_Trends")											
					%Script(name:="Plan_Only_Trends")											
				endif
			
			elseif(@ismbr(@relative("OEP_Qrtly Plan",0)))
				if(@ismbr(&OEP_QrtlyPlanStart:&OEP_QrtlyPlanEnd))																											
				%Script(name:="Qrtly_Trends")											
				endif												
			elseif(@ismbr("OEP_Yearly Plan"))	
				if(@ismbr(&OEP_YrlyPlanStart:&OEP_YrlyPlanEnd))													    													
				%Script(name:="Yearly_Trends")											
				endif												
		endif			     
												
	endif """

		def nonWeeklyScript = '''
		if(@ismbr(@relative("YearTotal",0)))			
				If(Not(@ismbr(&OEP_CurYr) and @ismbr(&OEP_StartMnth:&OEP_CurMnth)))		
					%Script(name:="Monthly_Trends")	
					%Script(name:="Forecast_Only_Trends")	
					endif 	
				endif    
		
		elseif(@ismbr(@relative("OEP_Qrtly Plan",0)))
			if(@ismbr(&OEP_QrtlyFcstStart:&OEP_QrtlyFcstEnd))																											
				%Script(name:="Qrtly_Trends")
			endif												
															
		elseif(@ismbr("OEP_Yearly Plan"))
				if(@ismbr(&OEP_YrlyFcstStart:&OEP_YrlyFcstEnd))																											
				%Script(name:="Yearly_Trends")											
			endif												
		endif	
	elseif(@ismbr("OEP_Plan"))	
		if(@ismbr(@relative("YearTotal",0)))
		if(@ismbr(&OEP_PlanStartYr:&OEP_PlanEndYr))													
				%Script(name:="Monthly_Trends")											
				%Script(name:="Plan_Only_Trends")											
				endif 											
				endif		

		  elseif(@ismbr(@relative("OEP_Qrtly Plan",0)))
				if(@ismbr(&OEP_QrtlyPlanStart:&OEP_QrtlyPlanEnd))																											
				%Script(name:="Qrtly_Trends")											
				endif												
			elseif(@ismbr("OEP_Yearly Plan"))
			 if(@ismbr(&OEP_YrlyPlanStart:&OEP_YrlyPlanEnd))													    														
				%Script(name:="Yearly_Trends")											
				endif												
		endif			     
												
	endif  '''
		boolean weeklyPlanExists = operation.application.getDimension(DimensionType.PERIOD, operation.cube).hasMember("OEP_Weekly Plan", operation.cube);
		if(weeklyPlanExists){
			trendLogic = trendLogic << weeklyScript;
		}else{
			trendLogic = trendLogic << nonWeeklyScript;
		}


	 cscript.append(trendLogic);

				if(operation.application.currencyMode == CurrencyMode.SIMPLIFIED_MULTI_CURRENCY) {
					cscript.append("\nENDIF \n");
				}
				 
				cscript.append(") \n");

				cscript.append("\nENDFIX \n");
			}

			String msg = "ENDFIX \n";
			cscript.append(msg);
			return cscript.toString();

        }
        
