Distancia entre datas
@CalcMgrDateDiff(data1,data2,"month")

@MDSHIFT
"Membro" = ((@MDSHIFT("Membro",-1,Years,,11,Period,@LIST(JAN:DEC))


