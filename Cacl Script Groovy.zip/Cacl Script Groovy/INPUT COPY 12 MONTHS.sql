/* GLOBALRANGE */
FIX (/*DIM:YEARS*/{V_RELEASE_YEAR},/*DIM:SCENARIO*/"IC_LAS_ACTUAL",/*DIM:VERSION*/"WORKING",/*DIM:BRICK*//*@RELATIVE("TOTAL BU",0)*/ "LINE ONCOLOGIA",/*DIM:PRODUCT*/@RELATIVE("LAS PRODUCTS",0),/*DIM:TERRITORY*/"SALES REPS ARGENTINA",/*DIM:PARTICIPANT*/"NA PARTICIPANT",/*DIM:ACCOUNT*/"ARGENTINA")
  %Template(name:="LAS_TEMPLATE",application:="LA_SPM",plantype:="LA_IC",dtps:=())
  /*CAPTION:FIX 1*/
  FIX (  /*DIM:PERIOD*/{V_RELEASE_MONTH})
      "ARS"(
        /*STARTCOMPONENT:SCRIPT*/
        @CALCMODE(BOTTOMUP);
        
        "COUNT AUX" = #MISSING;
        "START MONTH" = #MISSING;
        
        IF(@ISMBR("JAN"))
        
        	"START MONTH" = 1;
            
        ELSEIF(@ISMBR("DEC"))
        
        	"START MONTH" = 2;
            
        ENDIF;
        /*ENDCOMPONENT*/
      )
  ENDFIX
  /*CAPTION:FIX 2*/
  FIX (  /*DIM:PERIOD*/{V_RELEASE_MONTH}:"DEC")
      "ARS"(
        /*STARTCOMPONENT:SCRIPT*/
        @CALCMODE(BOTTOMUP);
        
        IF("START MONTH"->{V_RELEASE_MONTH} == 2)
        
        	IF("LAS PROD RELEASE"->{V_RELEASE_MONTH} <> #MISSING AND
               @MDSHIFT("LAS PROD RELEASE"->{V_RELEASE_MONTH},1,YEARS,,11,PERIOD,@LIST(Jan:Dec)) == #MISSING AND
               @PRIOR("LAS PROD RELEASE"->{V_RELEASE_MONTH}) == #MISSING AND	
               "COUNT AUX"->{V_RELEASE_MONTH} == #MISSING)
        		
                "COUNT AUX"->{V_RELEASE_MONTH}->{V_RELEASE_YEAR} = "COUNT AUX"->{V_RELEASE_MONTH} + 1;
                "LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
            
            ELSEIF("COUNT AUX"->{V_RELEASE_MONTH} == 1)
                
                "LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
                
          	ENDIF;      
        
        ELSEIF("START MONTH"->{V_RELEASE_MONTH} == 1)
        
        	IF("LAS PROD RELEASE"->{V_RELEASE_MONTH} <> #MISSING AND
               @NEXT("LAS PROD RELEASE"->{V_RELEASE_MONTH}) == #MISSING AND 
               @MDSHIFT("LAS PROD RELEASE"->{V_RELEASE_MONTH},-1,YEARS,,11,PERIOD,@LIST(Jan:Dec)) == #MISSING AND 
               "COUNT AUX"->{V_RELEASE_MONTH} == #MISSING)
            	
                "COUNT AUX"->{V_RELEASE_MONTH} = "COUNT AUX"->{V_RELEASE_MONTH} + 1;
            	"LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
                
            ELSEIF("COUNT AUX"->{V_RELEASE_MONTH} == 1)
                
                "LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
                
           	ENDIF;
                
        ELSE
        
        	IF("LAS PROD RELEASE"->{V_RELEASE_MONTH} <> #MISSING AND
               @NEXT("LAS PROD RELEASE"->{V_RELEASE_MONTH}) == #MISSING AND 
               @PRIOR("LAS PROD RELEASE"->{V_RELEASE_MONTH}) == #MISSING AND 
               "COUNT AUX"->{V_RELEASE_MONTH} == #MISSING)
            	
                "COUNT AUX"->{V_RELEASE_MONTH} = "COUNT AUX"->{V_RELEASE_MONTH} + 1;
            	"LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
                
            ELSEIF("COUNT AUX"->{V_RELEASE_MONTH} == 1)
                
                "LAS PROD RELEASE" = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
                
           	ENDIF;
        
        ENDIF;
        
        
        
        
        /*ENDCOMPONENT*/
      )
  ENDFIX
  /*CAPTION:FIX 3*/
  FIX (  /*DIM:PERIOD*/"JAN":{V_RELEASE_MONTH})
      "ARS"(
        /*STARTCOMPONENT:SCRIPT*/
        @CALCMODE(BOTTOMUP);
        
        IF("COUNT AUX"->{V_RELEASE_MONTH}->{V_RELEASE_YEAR} == 1)
                
            "LAS PROD RELEASE"->@MEMBER(@NEXTSIBLING(@CURRMBR(YEARS))) = "LAS PROD RELEASE"->{V_RELEASE_MONTH};
            "LAS PROD RELEASE"->@MEMBER(@NEXTSIBLING(@CURRMBR(YEARS)))->{V_RELEASE_MONTH} = #MISSING;
                
        ENDIF;
        /*ENDCOMPONENT*/
      )
  ENDFIX
ENDFIX